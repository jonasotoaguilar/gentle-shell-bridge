# ODD — plugin sections in gentle's command palette

Two repos: `gentle-shell-bridge` (the API plugins call) and `gentle-shell`/gentle-pi (owner of `/gentle:commands`). Size: large (cross-repo). The user calls the palette "panel de gentle shell commands".

## Specs

- **S1** — A plugin adds its entries to the palette in either of two shapes: into an existing section, or as a new section of its own. User: "agregar seccioones a panel de gentle shell comands, ya sea a una seccion exxistente o con categoria nueva en commands".
- **S2** — A contributed entry behaves like a native one: the palette lists it only while its command is registered, and selecting it runs that command.
- **S3** — Disposing the registration removes the entry, or the section when it was the plugin's own and is left empty.
- **S4** — Without host support the registration reports an unavailable reason through `/bridge-status`, never a silent no-op.
- **S5** — Order and grouping stay the host's: a contributed section appears with the host's sections and does not reorder them.

## Tasks

- **T1** (S1, S5) — Host: catalog accepts contributed sections/items at build time, in catalog order. Route: inline.
- **T2** (S1) — Bridge: `registerCommands` (existing section) and a section of its own, with disposer. Route: inline.
- **T3** (S2) — Selecting a contributed entry runs the plugin's command, including when the command disappears mid-session.
- **T4** (S3) — Dispose removes entry/section at the next palette open.
- **T5** (S4) — Unavailable path reported through `/bridge-status`.
- **T6** — Docs: contract.md, README, host docs.

## Log

- **L1** — "ahora veremos si podemos agregar 2 feactures para bridge, una es para agregar algun aparatado a panel commands [Image#1] ya sea en una seccion existe o propia, que seria ahi acciones rapidas como abrir panel etc, las que tiene."
- **L2** — "que preguntas, sabes siquiera de que hablamos? que es este plugin bridge, ya tenemos arto integrado, ni revisaste el contexto del proyecto"
- **L3** — "otro para agregar seccioones a panel de gentle shell comands, ya sea a una seccion exxistente o con categoria nueva en commands"
- **L4** (evidence, explorer mwgxgx3x-1-onuz) — The palette is a curated static catalog, "not a raw listing of every registered extension command" (`gentle-shell/lib/command-palette-catalog.ts:2-4`); `buildCommandPaletteGroups` keeps only catalog entries that are registered (`:33-49`). No extension point exists for a third-party group or item.
- **L5** (commits) — Host: `33bbe4e84` (merge of contributions in `lib/command-palette-catalog.ts`, `CONTRIBUTED_SECTION` = "Plugins" for an item that names no section). Bridge: `85f0f2b` (`registerCommands`, publishing on the same surface as keymaps).
- **L6** (evidence) — Covered by `tests/plugin-surface.test.ts`: joins a named section, opens an own section after the catalog, and an unregistered command is not listed (also for an own section that would be left empty).
- **L8** (delivery) — Same two PRs as plugin-keymap (bridge #6, host #80), both merged. CI never started on the host fork (0 runs for the head SHA).
