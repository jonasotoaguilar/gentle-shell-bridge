# ODD — plugin keymaps in gentle's Customize Keymap page

Two repos: `gentle-shell-bridge` (the API plugins call) and `gentle-shell`/gentle-pi (the owner of the Keymaps page, the bindings file and the collision rules). Size: large (multi-session, cross-repo, contract-level).

## Specs

- **S1** — A plugin registers one keymapped action through the bridge and the host lists it on the `Keymaps` page of `/gentle:customize`. User: "registrar keymap en customize keymap, para que aparezca ahi".
- **S2** — That row is edited with the host's own gestures on that page (Enter assigns, ⌫ disables, r restores the default), persists where the host persists its keymaps and applies after `/reload`. User: "se pueda modificar desde ahi el keymap del plugin" and "sumo compativlidad para modificar mendiante customize keymap de gentle".
- **S3** — The binding is real, not advertised: the plugin can resolve its own effective key and register the shortcut itself, so the row never claims a key that does nothing.
- **S4** — The host stays the single registry: environment overrides, reserved Pi keys and duplicate-key checks keep working for plugin ids exactly as for native ones. User's "compatibilidad" means the native rules, not a bypass.
- **S5** — Disposing the registration removes the plugin's row; a stale row or a stale key must not survive it.
- **S6** — Without host support, `registerKeymap` reports an unavailable reason through `/bridge-status`; it never fails silently.

## Tasks

- **T1** (S1, S6) — Host: extension-facing registry for keymap actions, and the bridge reads it. Route: inline.
- **T2** (S1, S2) — Host: `buildKeymapRows` and the collision helpers accept registered ids. Route: inline.
- **T3** (S1, S3) — Bridge: `registerKeymap` in the published API, disposer, and effective-key resolution for the plugin. Route: inline.
- **T4** (S4) — Collision + env-lock parity pinned by tests on both sides. Route: inline.
- **T5** (S2, S5) — End-to-end: register, reassign from the page, `/reload`, key works; dispose, key gone.
- **T6** — Docs: contract.md, README, and the host's docs for the new surface.

## Log

- **L1** — "ahora veremos si podemos agregar 2 feactures para bridge, una es para agregar algun aparatado a panel commands [Image#1] ya sea en una seccion existe o propia, que seria ahi acciones rapidas como abrir panel etc, las que tiene. Y otra para registrar keymap en customize keymap, para que aparezca ahi y se pueda modificar desde ahi el keymap del plugin integra y sumo compativlidad para modificar mendiante customize keymap de gentle."
- **L2** — "que preguntas, sabes siquiera de que hablamos? que es este plugin bridge, ya tenemos arto integrado, ni revisaste el contexto del proyecto"
- **L3** — "Y ahora ve como integrar lo que pedi, el bridge para registrar keymap de un plugin en gentle customize keymap. y otro para agregar seccioones a panel de gentle shell comands, ya sea a una seccion exxistente o con categoria nueva en commands"
- **L4** (evidence, explorer mwgxgx3x-1-onuz) — Host today: rows only from the static `KEYMAP_ACTIONS` (`gentle-shell/lib/keymaps.ts:34`) plus curated-catalog commands (`lib/keymaps-customize.ts:64-67`); no third-party registry of any kind; `keymaps.json` persists unknown ids (`parseKeymapFile`) but `keymapOwner`/`checkKeymap` ignore them, so an unknown id gets no row, no binding and no collision check. Bridge refuses the category at `src/row-names.ts:119-120` and `src/bus.ts:121-138`.
- **L5** (commits) — Host half: `33bbe4e84` on `feat/plugin-surfaces` in the gentle-shell worktree (5 files, 320 lines): `lib/plugin-surface.ts` reader, contributed actions in `lib/keymaps.ts` (lookup, effective key, source, collisions), the published keymap resolver, and `lib/keymaps-customize.ts` listing them. Bridge half: `85f0f2b` on `feat/plugin-surfaces` (6 files, 398 lines): `src/plugin-surface.ts`, the three optional API members, and the export/API contract lists.
- **L6** (evidence) — Host tests: `tests/plugin-surface.test.ts` 12/12; with `keymaps` and `keymaps-customize`, 25/26 — the one failure is `tests/command-palette.test.ts` unable to resolve `@earendil-works/pi-coding-agent` because neither checkout has `node_modules` installed (pre-existing, environment). Bridge tests: 691/691.
- **L7** (delivery defect + fix) — The first delivery was NOT visible: Pi loads the host from the installed git checkout (`/home/jona/.pi/agent/git/github.com/Gentleman-Programming/gentle-shell`, at 3dc902975) and the bridge from `gentle-shell-bridge-worktrees/bash-card-identity`, neither of which had this work. Restarting Pi could not help. Fix, applied to the running copies: `git apply` of the host patch onto the installed checkout (its `lib/keymaps.ts`, `lib/keymaps-customize.ts`, `lib/command-palette-catalog.ts` are byte-identical to the base commit, so it applies cleanly), and the bridge package entry in `~/.pi/agent/settings.json` repointed to `../../dev/projects/gentle-shell-bridge` (backup `settings.json.bak-plugin-surface`). Verified by importing the INSTALLED `lib/keymaps.ts`/`lib/keymaps-customize.ts`/`lib/command-palette-catalog.ts` with a published surface: action listed, row `Bash card: report state: alt+b`, palette group `Panel`, and the resolver answering `alt+b`. The installed checkout is now a dirty working tree: a package update replaces it and the patch must be reapplied (or the branch merged upstream).
- **L9** (delivery) — Bridge PR jonasotoaguilar/gentle-shell-bridge#6 merged as `90704ca`; host PR jonasotoaguilar/gentle-shell#80 merged as `b61559cf6`. Both merge commits, no squash. CI on the host fork never ran: `actions/runs?head_sha=33bbe4e8…` returned `total_count: 0` while the workflow is active and Actions is enabled — a GitHub-side condition, not a code failure; the proof for this change is the local suites plus the live TUI confirmation (L8). The installed upstream checkout still carries the hand-applied patch, so it is unaffected by the fork merge.
