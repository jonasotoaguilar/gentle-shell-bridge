# Wire contract — the bridge publishes, the host reads

Two repos, one handshake. The bridge already publishes its API at module load on
`Symbol.for("gentle-shell-bridge/api/v1")`; this contract adds a second, narrower global that
holds the plugin contributions the host must render. Direction matters: **the bridge publishes
and the host reads lazily**, so no load order, no session_start race, and no lifecycle in the host.

## The global

```ts
Symbol.for("gentle-shell-bridge/plugin-surface/v1")
```

```ts
interface PluginSurface {
  schema: 1;
  /** Live: the host calls this per menu/palette build, never once at startup. */
  keymaps(): readonly PluginKeymapAction[];
  commands(): readonly PluginCommandContribution[];
}

interface PluginKeymapAction {
  /** Plugin-owned, stable, never a built-in id and never `command:<name>`. */
  id: string;
  label: string;
  /** Optional environment variable that overrides the key, same semantics as a built-in action. */
  env?: string;
  defaultKey?: string;
  /** The slash command this action invokes, when it has one. */
  command?: string;
}

interface PluginCommandContribution {
  id: string;
  /** An existing palette section title, or a new one the plugin owns. */
  section?: string;
  label: string;
  /** The slash command the palette runs. Listed only while this command is registered. */
  command: string;
}
```

## Rules both sides obey

1. **Absent or malformed is empty.** A host that finds no global, a wrong `schema`, a throwing
   getter or a bad entry renders nothing from it and never throws. Fail closed, entry by entry.
2. **Live reads.** The host calls `keymaps()`/`commands()` at build time. A registration made
   during `session_start` is visible at the next menu or palette open; nothing is cached at startup.
3. **The host keeps ownership of its own rules.** A contributed key obeys the same reserved Pi
   keys, environment lock and duplicate-key checks as a native one; a contributed id takes part in
   collision detection exactly like a built-in id. No bypass.
4. **The plugin binds its own key.** `pi.registerShortcut` is called by the plugin (or the bridge
   on its behalf), never invented by the host; the host only renders the row and checks the key.
5. **No new host-side lifecycle.** The host never disposes a contribution. Removal is the bridge's
   disposer, and the next build simply stops seeing it.
